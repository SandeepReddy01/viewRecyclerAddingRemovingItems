package com.example.amar.addmultipleitems;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private RadioButton radioMobile;
    private EditText editMobile, editSim;
    private Button btnAddSim;
    private LinearLayout mobileLayout, ll;
    private LinearLayout addLayout, increLayout;
    private Button btnConfirm;
    private String strMobile, strSim;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioMobile = (RadioButton) findViewById(R.id.radio_mobile_no);
        editMobile = (EditText) findViewById(R.id.edit_mobile);
        editSim = (EditText) findViewById(R.id.edit_sim);
        btnAddSim = (Button) findViewById(R.id.button_add_sim);
        mobileLayout = (LinearLayout) findViewById(R.id.mobile_layout);
        addLayout = (LinearLayout) findViewById(R.id.add_layout);
        ll = (LinearLayout) findViewById(R.id.ll);
        btnConfirm = (Button)findViewById(R.id.btn_confirm);

        increLayout = new LinearLayout(MainActivity.this);

        if (radioMobile.isChecked()){

            mobileLayout.setVisibility(View.VISIBLE);

        }

        final LinearLayout linearLayoutForm = (LinearLayout) findViewById(R.id.linearLayoutForm);

        btnAddSim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final LinearLayout newView = (LinearLayout) getLayoutInflater().inflate(R.layout.custom_mobile_layout, null);
                newView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                Button btnRemove = (Button) newView.findViewById(R.id.btn_del);

                btnRemove.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        linearLayoutForm.removeView(newView);
                    }
                });

                linearLayoutForm.addView(newView);

            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                strMobile = editMobile.getText().toString();
                strSim = editSim.getText().toString();

                Intent intent = new Intent(MainActivity.this, ConfirmActivity.class);
                intent.putExtra("MOBILE_NO", strMobile);
                intent.putExtra("SIM", strSim);
                startActivity(intent);

            }
        });
    }
}
