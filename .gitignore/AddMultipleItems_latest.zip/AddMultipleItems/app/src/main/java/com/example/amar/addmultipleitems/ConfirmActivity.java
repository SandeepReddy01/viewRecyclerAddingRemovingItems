package com.example.amar.addmultipleitems;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by prasannapulagam on 3/28/18.
 */

public class ConfirmActivity extends AppCompatActivity {

    private TextView textMobile, textPUK;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cofirm);

        textMobile = (TextView) findViewById(R.id.text_mobile);
        textPUK = (TextView) findViewById(R.id.text_puk);

        String mobile = getIntent().getStringExtra("MOBILE_NO");
        String sim = getIntent().getStringExtra("SIM");


        for(int i=0;i<10;i++){
            textMobile.setText(mobile);
            textPUK.setText(sim);
        }

    }
}
